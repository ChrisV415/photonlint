# rules.py

class FoundryRules:
    def __init__(self, name):
        self.name = name

    def get_rules(self):
        # All dimensions in microns (um)
        # Based on typical Silicon Photonics processes (e.g., SOI)
        return {
            "min_width": 0.4,       # 400 nm minimum waveguide width
            "min_spacing": 0.2,     # 200 nm minimum spacing to prevent crosstalk
            "min_bend_radius": 5.0, # 5 um minimum bend radius
            "grid_size": 0.001      # 1 nm manufacturing grid snap
        }
