# report.py
"""
Generates a downloadable PDF DRC report, in addition to the CSV export.
"""
from io import BytesIO
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
)


def build_pdf_report(results_df, foundry_name, source_filename):
    """
    Build a PDF DRC report from the violations DataFrame and return it
    as raw bytes, suitable for a Streamlit download_button.
    """
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter,
                             topMargin=0.75 * inch, bottomMargin=0.75 * inch)
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("PLTitle", parent=styles["Title"], textColor=colors.HexColor("#1a1a2e"))
    meta_style = ParagraphStyle("PLMeta", parent=styles["Normal"], textColor=colors.grey)

    elements = [
        Paragraph("PhotonLint DRC Report", title_style),
        Spacer(1, 6),
        Paragraph(f"File: {source_filename}", meta_style),
        Paragraph(f"Foundry / PDK: {foundry_name}", meta_style),
        Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", meta_style),
        Spacer(1, 20),
    ]

    if "Status" in results_df.columns:
        status_text = results_df["Status"].iloc[0]
        elements.append(Paragraph(status_text, styles["Normal"]))
    else:
        n_critical = (results_df["Severity"] == "CRITICAL").sum()
        n_warning = (results_df["Severity"] == "WARNING").sum()
        summary = f"<b>{n_critical} CRITICAL</b> violation(s), <b>{n_warning} WARNING</b> flag(s) found."
        elements.append(Paragraph(summary, styles["Normal"]))
        elements.append(Spacer(1, 16))

        table_data = [list(results_df.columns)] + results_df.astype(str).values.tolist()
        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f5f5")]),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]))
        elements.append(table)

    elements.append(Spacer(1, 24))
    elements.append(Paragraph(
        "Note: bend-radius flags are heuristic (based on sharp turn angles "
        "over short edge segments) and should be manually reviewed alongside "
        "your foundry's official sign-off DRC before tape-out.",
        meta_style
    ))

    doc.build(elements)
    buffer.seek(0)
    return buffer.getvalue()
