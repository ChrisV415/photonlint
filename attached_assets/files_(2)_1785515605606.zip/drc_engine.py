# drc_engine.py
"""
Core DRC engine for PhotonLint.

Checks implemented:
  1. Grid snap      - vertices must land on the foundry manufacturing grid
  2. Minimum width  - feature width, measured across the true minor axis
                       (via minimum rotated bounding rectangle), not just
                       the raw axis-aligned bounding box
  3. Minimum spacing - closest distance between any two distinct polygons
                        on the waveguide layer (crosstalk risk)
  4. Minimum bend radius - HEURISTIC. True bend-radius checking requires
     reconstructing curved paths from discretized polygon vertices and
     fitting arcs, which is out of scope for this MVP. Instead we flag
     any vertex where the path turns sharply (large angle change) between
     short edge segments, as a proxy for "this corner is tighter than the
     foundry's minimum bend radius would produce." This will both miss
     real violations and occasionally flag sharp-but-legal corners
     (e.g. deliberate right-angle couplers) - treat it as a WARNING-level
     signal to manually inspect, not a CRITICAL pass/fail the way spacing
     and grid-snap are.
"""
import gdspy
import pandas as pd
import numpy as np
from shapely.geometry import Polygon
from shapely.validation import make_valid


def _to_shapely(poly_points):
    """Convert a gdspy polygon (Nx2 array) into a valid shapely Polygon."""
    try:
        p = Polygon(poly_points)
        if not p.is_valid:
            p = make_valid(p)
        return p
    except Exception:
        return None


def _effective_width(poly_points):
    """
    Estimate the true minimum feature width of a polygon by taking its
    minimum rotated bounding rectangle and returning the shorter side.
    This correctly handles waveguides that aren't axis-aligned, unlike
    a plain bounding-box width/height check.
    """
    p = _to_shapely(poly_points)
    if p is None or p.is_empty:
        return None
    rect = p.minimum_rotated_rectangle
    coords = list(rect.exterior.coords)
    if len(coords) < 4:
        return None
    side_a = np.linalg.norm(np.array(coords[0]) - np.array(coords[1]))
    side_b = np.linalg.norm(np.array(coords[1]) - np.array(coords[2]))
    return min(side_a, side_b)


def _check_bend_radius(poly_points, min_bend_radius, angle_threshold_deg=25.0):
    """
    Heuristic sharp-corner detector. Returns a list of (point, turn_angle_deg)
    for vertices where the path direction changes sharply across a short
    edge, which for a waveguide could indicate a bend tighter than the
    foundry's minimum allowed radius.
    """
    flags = []
    n = len(poly_points)
    if n < 3:
        return flags
    for i in range(n):
        p_prev = np.array(poly_points[i - 1])
        p_curr = np.array(poly_points[i])
        p_next = np.array(poly_points[(i + 1) % n])

        v1 = p_curr - p_prev
        v2 = p_next - p_curr
        len1, len2 = np.linalg.norm(v1), np.linalg.norm(v2)
        if len1 < 1e-9 or len2 < 1e-9:
            continue

        cos_angle = np.clip(np.dot(v1, v2) / (len1 * len2), -1.0, 1.0)
        turn_angle = np.degrees(np.arccos(cos_angle))

        # Short edges + sharp turn = tighter effective radius than the
        # foundry minimum would allow for a smooth waveguide bend.
        if turn_angle > angle_threshold_deg and min(len1, len2) < min_bend_radius:
            flags.append((tuple(p_curr), round(turn_angle, 1)))
    return flags


def run_drc(gds_path, rules, layer=(1, 0)):
    """
    Core DRC Engine. Parses GDS and checks geometric rules against the
    given foundry ruleset. Returns a pandas DataFrame of violations
    (or a single-row status DataFrame if the file can't be checked or
    everything passes).
    """
    try:
        gdsii = gdspy.GdsLibrary()
        gdsii.read_gds(gds_path)
        cell = gdsii.top_level()[0]
    except Exception as e:
        return pd.DataFrame({"Status": [f"❌ Error loading GDS file: {str(e)}"]})

    polygons = cell.get_polygons(by_spec=True).get(layer, [])

    if not polygons:
        return pd.DataFrame({
            "Status": [f"⚠️ No polygons found on Layer {layer}. "
                       f"Ensure your waveguides are on the correct layer."]
        })

    min_width = rules["min_width"]
    min_spacing = rules["min_spacing"]
    min_bend_radius = rules["min_bend_radius"]
    grid = rules["grid_size"]

    violations = []
    off_grid_count = 0
    shapely_polys = []

    # --- Per-polygon checks: grid snap, width, bend radius ---
    for poly in polygons:
        for point in poly:
            if (point[0] % grid > 1e-6) or (point[1] % grid > 1e-6):
                off_grid_count += 1

        width = _effective_width(poly)
        if width is not None and width < min_width:
            min_x, min_y = np.min(poly, axis=0)
            violations.append({
                "Rule": "Minimum Feature Width",
                "Requirement": f"{min_width} µm",
                "Measured": f"{width:.3f} µm",
                "Location": f"~({min_x:.2f}, {min_y:.2f})",
                "Severity": "CRITICAL",
            })

        bend_flags = _check_bend_radius(poly, min_bend_radius)
        for (pt, angle) in bend_flags:
            violations.append({
                "Rule": "Minimum Bend Radius (heuristic)",
                "Requirement": f"{min_bend_radius} µm",
                "Measured": f"turn angle {angle}°",
                "Location": f"~({pt[0]:.2f}, {pt[1]:.2f})",
                "Severity": "WARNING",
            })

        sp = _to_shapely(poly)
        if sp is not None and not sp.is_empty:
            shapely_polys.append(sp)

    if off_grid_count > 0:
        violations.append({
            "Rule": "Grid Snap",
            "Requirement": f"{grid} µm",
            "Measured": f"{off_grid_count} off-grid vertices",
            "Location": "multiple",
            "Severity": "WARNING",
        })

    # --- Pairwise checks: minimum spacing between distinct polygons ---
    # O(n^2): fine for MVP-scale layouts. For large full-chip layouts this
    # should be replaced with a spatial index (e.g. an R-tree) before
    # comparing every pair.
    n = len(shapely_polys)
    for i in range(n):
        for j in range(i + 1, n):
            try:
                dist = shapely_polys[i].distance(shapely_polys[j])
            except Exception:
                continue
            if 0 < dist < min_spacing:
                c = shapely_polys[i].centroid
                violations.append({
                    "Rule": "Minimum Spacing (crosstalk risk)",
                    "Requirement": f"{min_spacing} µm",
                    "Measured": f"{dist:.3f} µm",
                    "Location": f"~({c.x:.2f}, {c.y:.2f})",
                    "Severity": "CRITICAL",
                })

    if not violations:
        return pd.DataFrame({"Status": ["✅ PASS: All checked DRC rules passed! Ready for tape-out."]})

    df = pd.DataFrame(violations)
    # Sort so CRITICAL issues surface first
    severity_order = {"CRITICAL": 0, "WARNING": 1}
    df["_sort"] = df["Severity"].map(severity_order).fillna(2)
    df = df.sort_values("_sort").drop(columns="_sort").reset_index(drop=True)
    return df
