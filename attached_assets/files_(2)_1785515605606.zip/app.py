# app.py
import streamlit as st
import pandas as pd
import os
import tempfile
from drc_engine import run_drc
from rules import FoundryRules
from report import build_pdf_report

# Page configuration
st.set_page_config(page_title="PhotonLint - SiPho DRC", page_icon="💡", layout="wide")

st.title("💡 PhotonLint")
st.markdown("### The Cloud-Native Design Rule Checker for Silicon Photonics")
st.markdown(
    "Upload your chip layout to check waveguides, spacing, and bends against "
    "foundry PDK rules before tape-out — the insurance policy against a "
    "$100k+ failed wafer run."
)

# Sidebar for rules selection
st.sidebar.header("⚙️ Foundry Rules")
foundry_name = st.sidebar.selectbox(
    "Select Target Foundry / PDK",
    ("GlobalFoundries 45SPCLO (Mock)", "AIM Photonics (Mock)", "Tower Semiconductor (Mock)")
)

rules_obj = FoundryRules(foundry_name)
rules = rules_obj.get_rules()

st.sidebar.markdown("---")
st.sidebar.subheader("Current Ruleset:")
st.sidebar.json(rules)

st.sidebar.markdown("---")
st.sidebar.caption(
    "⚠️ These are mock, illustrative rule values for the MVP — not the real "
    "GlobalFoundries / AIM / Tower PDK design manuals. Swap in the real "
    "foundry rule values in `rules.py` before using this for an actual "
    "tape-out decision."
)

# Main area for file upload
st.markdown("---")
uploaded_file = st.file_uploader("Upload your GDSII Layout (`.gds`)", type=["gds"])
st.caption(
    "Note: `.oas` (OASIS) files aren't supported yet — gdspy only reads GDSII. "
    "OASIS support would require a KLayout-based backend."
)

if uploaded_file is not None:
    st.info(f"Processing file: **{uploaded_file.name}** against **{foundry_name}** rules...")

    with tempfile.NamedTemporaryFile(delete=False, suffix=".gds") as tmp_file:
        tmp_file.write(uploaded_file.getvalue())
        tmp_path = tmp_file.name

    try:
        with st.spinner("Running geometric checks (grid snap, width, spacing, bend radius)..."):
            results_df = run_drc(tmp_path, rules)

        st.subheader("📊 DRC Report")

        if "Status" in results_df.columns:
            if "PASS" in results_df["Status"][0]:
                st.success(results_df["Status"][0])
            else:
                st.warning(results_df["Status"][0])
        else:
            n_critical = (results_df["Severity"] == "CRITICAL").sum()
            n_warning = (results_df["Severity"] == "WARNING").sum()
            st.error(f"⚠️ {n_critical} CRITICAL violation(s), {n_warning} WARNING flag(s) detected.")
            st.dataframe(results_df, use_container_width=True, hide_index=True)

            col1, col2 = st.columns(2)
            with col1:
                csv = results_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="📥 Download Report (CSV)",
                    data=csv,
                    file_name='photonlint_report.csv',
                    mime='text/csv',
                )
            with col2:
                pdf_bytes = build_pdf_report(results_df, foundry_name, uploaded_file.name)
                st.download_button(
                    label="📄 Download Report (PDF)",
                    data=pdf_bytes,
                    file_name='photonlint_report.pdf',
                    mime='application/pdf',
                )

    except Exception as e:
        st.error(f"An error occurred during processing: {e}")
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

else:
    st.markdown("""
    #### 🚀 Why use PhotonLint?
    - **Save Money:** A failed tape-out costs $100k–$500k+ and a 3–4 month delay for the next shuttle run. Catch errors before they hit the fab.
    - **Save Time:** No heavy, six-figure EDA install (Synopsys/Cadence). Run checks in seconds, in the browser.
    - **Built for PICs:** Checks minimum width, minimum spacing (optical crosstalk risk), grid snap, and flags potentially sharp bend-radius violations.

    *Upload a file to get started!*
    """)

st.markdown("---")
st.caption("PhotonLint MVP v0.2 | Built for the Photonic AI Revolution")
