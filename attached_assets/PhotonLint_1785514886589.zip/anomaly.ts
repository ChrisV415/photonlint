/**
 * Pulsum Usage Fraud Detection
 *
 * Runs after every event ingestion batch.
 * Detects three patterns:
 *   1. Spike     — today's events > 3× 30-day daily average
 *   2. Silent    — customer has gone quiet for > 2× their normal interval
 *   3. New metric — a metric_name never seen before appears suddenly
 *
 * Findings are written to the audit_logs table with action = "anomaly_*"
 * and surfaced via the existing Resend alert system.
 */

import { db } from "@workspace/db";
import {
  usageEventsTable,
  customersTable,
  auditLogsTable,
} from "@workspace/db";
import { eq, and, gte, lte, count, max, sql } from "drizzle-orm";
import { writeAuditLog } from "./audit";

export type AnomalySeverity = "low" | "medium" | "high";

export interface AnomalyFinding {
  customerId:  string;
  type:        "spike" | "silence" | "new_metric";
  severity:    AnomalySeverity;
  metricName:  string;
  description: string;
  currentValue: number;
  baselineValue: number;
  multiplier:  number;
  detectedAt:  Date;
}

// ── Thresholds ────────────────────────────────────────────────────────────────
const SPIKE_LOW    = 2.0;   // 2× baseline  → low
const SPIKE_MEDIUM = 3.0;   // 3× baseline  → medium
const SPIKE_HIGH   = 5.0;   // 5× baseline  → high
const SILENCE_MULTIPLIER = 2.0; // 2× normal interval = silent

// ── Helpers ───────────────────────────────────────────────────────────────────

function severityFromMultiplier(m: number): AnomalySeverity {
  if (m >= SPIKE_HIGH)   return "high";
  if (m >= SPIKE_MEDIUM) return "medium";
  return "low";
}

async function alreadyFlagged(
  customerId: string,
  metricName: string,
  type: string,
  since: Date
): Promise<boolean> {
  const rows = await db
    .select({ cnt: count() })
    .from(auditLogsTable)
    .where(
      and(
        eq(auditLogsTable.customerId, customerId),
        eq(auditLogsTable.action, `anomaly_${type}`),
        gte(auditLogsTable.createdAt, since)
      )
    );
  return Number(rows[0]?.cnt ?? 0) > 0;
}

// ── Spike detection ───────────────────────────────────────────────────────────

async function detectSpike(
  customerId: string,
  metricName: string
): Promise<AnomalyFinding | null> {
  const now       = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const thirtyDaysAgo = new Date(now);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  // Today's count
  const [todayRow] = await db
    .select({ cnt: count() })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName),
        gte(usageEventsTable.recordedAt, todayStart)
      )
    );
  const todayCount = Number(todayRow?.cnt ?? 0);
  if (todayCount === 0) return null;

  // 30-day daily average (excluding today)
  const [baselineRow] = await db
    .select({ cnt: count() })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName),
        gte(usageEventsTable.recordedAt, thirtyDaysAgo),
        lte(usageEventsTable.recordedAt, todayStart)
      )
    );
  const totalLast30 = Number(baselineRow?.cnt ?? 0);
  const dailyAvg    = totalLast30 / 30;

  if (dailyAvg < 1) return null; // not enough history
  const multiplier = todayCount / dailyAvg;
  if (multiplier < SPIKE_LOW) return null;

  // Don't re-flag the same spike today
  const alreadySent = await alreadyFlagged(customerId, metricName, "spike", todayStart);
  if (alreadySent) return null;

  return {
    customerId,
    type:        "spike",
    severity:    severityFromMultiplier(multiplier),
    metricName,
    description: `${metricName} spiked ${multiplier.toFixed(1)}× above 30-day average (${todayCount} events today vs ${dailyAvg.toFixed(0)} avg/day)`,
    currentValue:  todayCount,
    baselineValue: dailyAvg,
    multiplier,
    detectedAt: now,
  };
}

// ── Silence detection ─────────────────────────────────────────────────────────

async function detectSilence(
  customerId: string,
  metricName: string
): Promise<AnomalyFinding | null> {
  const now = new Date();
  const thirtyDaysAgo = new Date(now);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  // Find the last event
  const [lastRow] = await db
    .select({ lastSeen: max(usageEventsTable.recordedAt) })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName)
      )
    );

  const lastSeen = lastRow?.lastSeen;
  if (!lastSeen) return null;

  // Calculate average interval between events over last 30 days
  const [countRow] = await db
    .select({ cnt: count() })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName),
        gte(usageEventsTable.recordedAt, thirtyDaysAgo)
      )
    );

  const eventCount = Number(countRow?.cnt ?? 0);
  if (eventCount < 5) return null; // not enough history to establish normal interval

  const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;
  const avgIntervalMs = thirtyDaysMs / eventCount;
  const silenceMs     = now.getTime() - new Date(lastSeen).getTime();
  const multiplier    = silenceMs / avgIntervalMs;

  if (multiplier < SILENCE_MULTIPLIER) return null;

  // Don't re-flag silence more than once per day
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const alreadySent = await alreadyFlagged(customerId, metricName, "silence", todayStart);
  if (alreadySent) return null;

  const hoursAgo = Math.round(silenceMs / (1000 * 60 * 60));

  return {
    customerId,
    type:        "silence",
    severity:    multiplier >= 5 ? "high" : multiplier >= 3 ? "medium" : "low",
    metricName,
    description: `${metricName} has been silent for ${hoursAgo}h (${multiplier.toFixed(1)}× normal interval of ${Math.round(avgIntervalMs / 60000)}min)`,
    currentValue:  0,
    baselineValue: avgIntervalMs / 60000,
    multiplier,
    detectedAt: now,
  };
}

// ── New metric detection ───────────────────────────────────────────────────────

async function detectNewMetric(
  customerId: string,
  metricName: string
): Promise<AnomalyFinding | null> {
  const oneDayAgo = new Date();
  oneDayAgo.setDate(oneDayAgo.getDate() - 1);

  // Check if this metric existed before the last 24 hours
  const [olderRow] = await db
    .select({ cnt: count() })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName),
        lte(usageEventsTable.recordedAt, oneDayAgo)
      )
    );

  if (Number(olderRow?.cnt ?? 0) > 0) return null; // not new

  // Count events in last 24h for this metric
  const [recentRow] = await db
    .select({ cnt: count() })
    .from(usageEventsTable)
    .where(
      and(
        eq(usageEventsTable.customerId, customerId),
        eq(usageEventsTable.metricName, metricName),
        gte(usageEventsTable.recordedAt, oneDayAgo)
      )
    );

  const recentCount = Number(recentRow?.cnt ?? 0);
  if (recentCount < 3) return null; // only flag if there's real volume

  // Don't re-flag the same new metric
  const alreadySent = await alreadyFlagged(customerId, metricName, "new_metric", oneDayAgo);
  if (alreadySent) return null;

  return {
    customerId,
    type:        "new_metric",
    severity:    "low",
    metricName,
    description: `New metric "${metricName}" appeared for the first time (${recentCount} events in last 24h)`,
    currentValue:  recentCount,
    baselineValue: 0,
    multiplier:  recentCount,
    detectedAt: new Date(),
  };
}

// ── Send anomaly alert email ───────────────────────────────────────────────────

async function sendAnomalyEmail(
  email: string,
  finding: AnomalyFinding
): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return;

  const from = process.env.ALERT_FROM_EMAIL ?? "alerts@pulsum.cloud";
  const severityColor = {
    low:    "#f59e0b",
    medium: "#ef4444",
    high:   "#7f1d1d",
  }[finding.severity];

  const severityLabel = finding.severity.toUpperCase();
  const typeLabel = {
    spike:      "Usage spike detected",
    silence:    "Customer gone silent",
    new_metric: "New metric appeared",
  }[finding.type];

  await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization:  `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: email,
      subject: `[${severityLabel}] ${typeLabel} — ${finding.customerId}`,
      html: `
        <div style="font-family:system-ui,sans-serif;max-width:520px;margin:0 auto;padding:24px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px;">
            <span style="background:${severityColor};color:white;font-size:11px;font-weight:600;padding:3px 10px;border-radius:20px;text-transform:uppercase;">${severityLabel}</span>
            <span style="font-size:16px;font-weight:600;color:#111;">${typeLabel}</span>
          </div>

          <table style="width:100%;border-collapse:collapse;margin-bottom:20px;">
            <tr style="border-bottom:1px solid #f0f0f0;">
              <td style="padding:8px 0;color:#666;font-size:13px;">Customer</td>
              <td style="padding:8px 0;text-align:right;font-weight:500;font-size:13px;">${finding.customerId}</td>
            </tr>
            <tr style="border-bottom:1px solid #f0f0f0;">
              <td style="padding:8px 0;color:#666;font-size:13px;">Metric</td>
              <td style="padding:8px 0;text-align:right;font-weight:500;font-size:13px;font-family:monospace;">${finding.metricName}</td>
            </tr>
            <tr style="border-bottom:1px solid #f0f0f0;">
              <td style="padding:8px 0;color:#666;font-size:13px;">Detected</td>
              <td style="padding:8px 0;text-align:right;font-size:13px;">${finding.detectedAt.toLocaleString()}</td>
            </tr>
          </table>

          <div style="background:#f9fafb;border-radius:8px;padding:14px;font-size:13px;color:#444;line-height:1.6;margin-bottom:20px;">
            ${finding.description}
          </div>

          <a href="https://app.pulsum.cloud/customers/${finding.customerId}" 
             style="display:inline-block;background:#4f46e5;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:500;">
            Review in Pulsum →
          </a>

          <p style="margin-top:20px;font-size:12px;color:#aaa;">
            Pulsum fraud detection · 
            <a href="https://app.pulsum.cloud/settings" style="color:#aaa;">Manage alerts</a>
          </p>
        </div>
      `,
    }),
  });
}

// ── Main: run all detectors for a customer + metric ───────────────────────────

export async function runAnomalyDetection(
  customerId: string,
  metricName: string
): Promise<AnomalyFinding[]> {
  const findings: AnomalyFinding[] = [];

  const [spike, silence, newMetric] = await Promise.all([
    detectSpike(customerId, metricName),
    detectSilence(customerId, metricName),
    detectNewMetric(customerId, metricName),
  ]);

  for (const finding of [spike, silence, newMetric]) {
    if (!finding) continue;
    findings.push(finding);

    // Write to audit log
    await writeAuditLog({
      customerId: finding.customerId,
      action:     `anomaly_${finding.type}`,
      amount:     finding.multiplier,
      providerResponse: {
        severity:    finding.severity,
        metricName:  finding.metricName,
        description: finding.description,
        currentValue:  finding.currentValue,
        baselineValue: finding.baselineValue,
      },
    }).catch(console.error);

    // Send email alert if customer has an email
    const [customer] = await db
      .select({ email: customersTable.email })
      .from(customersTable)
      .where(eq(customersTable.id, customerId))
      .limit(1);

    if (customer?.email) {
      await sendAnomalyEmail(customer.email, finding).catch(console.error);
    }
  }

  return findings;
}

// ── Org-level scan (call from admin or cron) ──────────────────────────────────

export async function scanOrgForAnomalies(orgId: string): Promise<AnomalyFinding[]> {
  const customers = await db
    .select({ id: customersTable.id })
    .from(customersTable)
    .where(eq(customersTable.orgId, orgId));

  const allFindings: AnomalyFinding[] = [];

  for (const customer of customers) {
    // Get distinct metrics for this customer
    const metrics = await db
      .selectDistinct({ metricName: usageEventsTable.metricName })
      .from(usageEventsTable)
      .where(eq(usageEventsTable.customerId, customer.id));

    for (const { metricName } of metrics) {
      const findings = await runAnomalyDetection(customer.id, metricName);
      allFindings.push(...findings);
    }
  }

  return allFindings;
}
