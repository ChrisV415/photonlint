import { useState, useEffect } from "react";
import { useOrgApi } from "@/lib/org-api";

interface AnomalyFinding {
  id:            string;
  customerId:    string;
  type:          "spike" | "silence" | "new_metric";
  severity:      "low" | "medium" | "high";
  metricName:    string;
  description:   string;
  currentValue:  number;
  baselineValue: number;
  multiplier:    number;
  detectedAt:    string;
}

interface Summary {
  high:   number;
  medium: number;
  low:    number;
  total:  number;
}

const SEVERITY_STYLES = {
  high:   { bg: "bg-red-50",    text: "text-red-700",    border: "border-red-200",    badge: "bg-red-100 text-red-700"    },
  medium: { bg: "bg-amber-50",  text: "text-amber-700",  border: "border-amber-200",  badge: "bg-amber-100 text-amber-700"  },
  low:    { bg: "bg-yellow-50", text: "text-yellow-700", border: "border-yellow-200", badge: "bg-yellow-100 text-yellow-700" },
};

const TYPE_LABELS = {
  spike:      "Usage spike",
  silence:    "Gone silent",
  new_metric: "New metric",
};

const TYPE_ICONS = {
  spike:      "↑",
  silence:    "—",
  new_metric: "★",
};

export default function AnomaliesPage() {
  const api = useOrgApi();
  const [findings, setFindings] = useState<AnomalyFinding[]>([]);
  const [summary,  setSummary]  = useState<Summary | null>(null);
  const [loading,  setLoading]  = useState(true);
  const [scanning, setScanning] = useState(false);
  const [filter,   setFilter]   = useState<"all" | "high" | "medium" | "low">("all");

  async function load() {
    setLoading(true);
    try {
      const [findingsRes, summaryRes] = await Promise.all([
        api.get("/v1/anomalies").then(r => r.json()),
        api.get("/v1/anomalies/summary").then(r => r.json()),
      ]);
      setFindings(findingsRes.findings ?? []);
      setSummary(summaryRes);
    } finally {
      setLoading(false);
    }
  }

  async function runScan() {
    setScanning(true);
    try {
      await api.post("/v1/anomalies/scan", {});
      await load();
    } finally {
      setScanning(false);
    }
  }

  useEffect(() => { load(); }, []);

  const filtered = filter === "all"
    ? findings
    : findings.filter(f => f.severity === filter);

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Fraud detection</h1>
          <p className="mt-1 text-sm text-slate-500">
            Anomalies detected across customer usage — spikes, silence, and new patterns.
          </p>
        </div>
        <button
          onClick={runScan}
          disabled={scanning}
          className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 transition-colors"
        >
          {scanning ? "Scanning…" : "Scan now"}
        </button>
      </div>

      {/* Summary cards */}
      {summary && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Total (7 days)", value: summary.total,  color: "text-slate-900" },
            { label: "High",           value: summary.high,   color: "text-red-600"   },
            { label: "Medium",         value: summary.medium, color: "text-amber-600" },
            { label: "Low",            value: summary.low,    color: "text-yellow-600"},
          ].map(card => (
            <div key={card.label} className="rounded-xl bg-slate-50 border border-slate-200 p-4">
              <p className="text-xs text-slate-500 mb-1">{card.label}</p>
              <p className={`text-2xl font-semibold ${card.color}`}>{card.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2">
        {(["all", "high", "medium", "low"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors capitalize ${
              filter === f
                ? "bg-indigo-600 text-white"
                : "border border-slate-200 text-slate-600 hover:bg-slate-50"
            }`}
          >
            {f === "all" ? `All (${findings.length})` : f}
          </button>
        ))}
      </div>

      {/* Findings list */}
      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-12 text-center">
          <p className="text-2xl mb-2">✓</p>
          <p className="font-medium text-slate-700">No anomalies detected</p>
          <p className="text-sm text-slate-500 mt-1">
            All customer usage patterns look normal for the past 7 days.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(finding => {
            const styles = SEVERITY_STYLES[finding.severity];
            return (
              <div
                key={finding.id}
                className={`rounded-xl border p-4 ${styles.bg} ${styles.border}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 min-w-0">
                    {/* Type icon */}
                    <div className={`mt-0.5 flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg text-sm font-bold ${styles.badge}`}>
                      {TYPE_ICONS[finding.type]}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-sm font-medium ${styles.text}`}>
                          {TYPE_LABELS[finding.type]}
                        </span>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${styles.badge}`}>
                          {finding.severity}
                        </span>
                        <code className="rounded bg-white/60 px-1.5 py-0.5 text-xs text-slate-600">
                          {finding.metricName}
                        </code>
                      </div>
                      <p className="mt-1 text-sm text-slate-600 leading-relaxed">
                        {finding.description}
                      </p>
                    </div>
                  </div>

                  {/* Stats */}
                  <div className="flex-shrink-0 text-right">
                    <p className={`text-lg font-semibold ${styles.text}`}>
                      {finding.multiplier.toFixed(1)}×
                    </p>
                    <p className="text-xs text-slate-500">multiplier</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between border-t border-white/40 pt-3">
                  <div className="flex items-center gap-4 text-xs text-slate-500">
                    <span>Customer: <strong className="text-slate-700">{finding.customerId}</strong></span>
                    <span>{new Date(finding.detectedAt).toLocaleString()}</span>
                  </div>
                  <a
                    href={`/customers/${finding.customerId}`}
                    className="text-xs font-medium text-indigo-600 hover:text-indigo-700"
                  >
                    View customer →
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Explainer */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <h3 className="text-sm font-medium text-slate-900 mb-3">What Pulsum monitors</h3>
        <div className="grid grid-cols-3 gap-4">
          {[
            {
              icon: "↑",
              title: "Usage spikes",
              desc: "Event volume exceeds 2–5× the 30-day daily average. May indicate bot activity or runaway automation.",
            },
            {
              icon: "—",
              title: "Silent customers",
              desc: "Customer stops sending events for 2× their normal interval. May indicate integration failure or churn risk.",
            },
            {
              icon: "★",
              title: "New metrics",
              desc: "A metric name that's never been seen before appears with volume. May indicate an integration change or misconfiguration.",
            },
          ].map(item => (
            <div key={item.title} className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-bold text-sm">{item.icon}</span>
                <span className="text-sm font-medium text-slate-700">{item.title}</span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
