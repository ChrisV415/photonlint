import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { auditLogsTable, customersTable } from "@workspace/db";
import { eq, and, like, desc, count, gte } from "drizzle-orm";
import { requireClerkOrg, type OrgRequest } from "../../middlewares/clerkAuth";
import { scanOrgForAnomalies } from "../../lib/anomaly";

const router: IRouter = Router();

// ── GET /v1/anomalies — list all anomaly findings for the org ─────────────────
router.get("/v1/anomalies", requireClerkOrg, async (req, res): Promise<void> => {
  const { tenantId } = req as OrgRequest;

  const since = req.query.since
    ? new Date(req.query.since as string)
    : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000); // default: last 7 days

  const severity = req.query.severity as string | undefined;
  const limit    = Math.min(Number(req.query.limit ?? 50), 200);

  // Pull anomaly audit log entries
  const rows = await db
    .select()
    .from(auditLogsTable)
    .where(
      and(
        like(auditLogsTable.action, "anomaly_%"),
        gte(auditLogsTable.createdAt, since)
      )
    )
    .orderBy(desc(auditLogsTable.createdAt))
    .limit(limit);

  // Filter by severity if requested
  const filtered = severity
    ? rows.filter(r => (r.providerResponse as any)?.severity === severity)
    : rows;

  // Shape for frontend
  const findings = filtered.map(r => {
    const meta = r.providerResponse as any ?? {};
    return {
      id:           r.id,
      customerId:   r.customerId,
      type:         r.action.replace("anomaly_", ""),
      severity:     meta.severity ?? "low",
      metricName:   meta.metricName ?? "",
      description:  meta.description ?? "",
      currentValue:  meta.currentValue ?? 0,
      baselineValue: meta.baselineValue ?? 0,
      multiplier:   Number(r.amount ?? 0),
      detectedAt:   r.createdAt,
    };
  });

  res.json({
    findings,
    total: findings.length,
    since: since.toISOString(),
  });
});

// ── GET /v1/anomalies/summary — counts by severity for dashboard badge ────────
router.get("/v1/anomalies/summary", requireClerkOrg, async (req, res): Promise<void> => {
  const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const rows = await db
    .select({ providerResponse: auditLogsTable.providerResponse, createdAt: auditLogsTable.createdAt })
    .from(auditLogsTable)
    .where(
      and(
        like(auditLogsTable.action, "anomaly_%"),
        gte(auditLogsTable.createdAt, since)
      )
    );

  const counts = { high: 0, medium: 0, low: 0, total: rows.length };
  for (const r of rows) {
    const sev = (r.providerResponse as any)?.severity as string;
    if (sev === "high")   counts.high++;
    else if (sev === "medium") counts.medium++;
    else counts.low++;
  }

  res.json(counts);
});

// ── POST /v1/anomalies/scan — trigger manual scan for the org ─────────────────
router.post("/v1/anomalies/scan", requireClerkOrg, async (req, res): Promise<void> => {
  const { tenantId } = req as OrgRequest;

  try {
    const findings = await scanOrgForAnomalies(tenantId);
    res.json({
      scanned: true,
      findingsCount: findings.length,
      findings: findings.map(f => ({
        customerId:  f.customerId,
        type:        f.type,
        severity:    f.severity,
        metricName:  f.metricName,
        description: f.description,
        multiplier:  Math.round(f.multiplier * 10) / 10,
      })),
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: message });
  }
});

export default router;
