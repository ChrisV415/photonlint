// Add this to artifacts/api-server/src/routes/v1/events.ts
// After the existing event INSERT, add the anomaly check.
// This is a PATCH showing only what changes — merge with your existing events.ts

import { runAnomalyDetection } from "../../lib/anomaly";

// ── Inside your POST /v1/events handler, after the db.insert: ─────────────────
//
// Current code ends with:
//   res.status(202).json({ status: "accepted", id });
//
// Replace that final line with:

async function checkAnomalyAfterIngest(customerId: string, metricName: string) {
  // Non-blocking — never delays the 202 response
  setImmediate(async () => {
    try {
      await runAnomalyDetection(customerId, metricName);
    } catch (err) {
      console.error("[anomaly] detection failed:", err);
    }
  });
}

// ── Inside POST /v1/events, after your insert succeeds: ───────────────────────
//
//   const id = crypto.randomUUID();
//   await db.insert(usageEventsTable).values({ ... });
//
//   checkAnomalyAfterIngest(customerId, metricName);  // ← ADD THIS LINE
//   res.status(202).json({ status: "accepted", id });
//
// ── Inside POST /v1/events/batch, after all inserts succeed: ──────────────────
//
//   const uniqueMetrics = [...new Set(parsed.data.events.map(e => e.metric))];
//   for (const metric of uniqueMetrics) {
//     checkAnomalyAfterIngest(customerId, metric);    // ← ADD THIS LOOP
//   }
//   res.status(202).json({ status: "accepted", count: ids.length, ids });

export { checkAnomalyAfterIngest };
